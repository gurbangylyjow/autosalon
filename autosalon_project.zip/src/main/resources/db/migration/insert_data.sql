INSERT INTO users (...);
INSERT INTO cars (...);